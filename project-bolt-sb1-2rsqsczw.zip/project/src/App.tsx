import { useState } from 'react';
import { Smartphone, Github, Zap, Shield } from 'lucide-react';
import { GitHubConnect } from '@/components/GitHubConnect';
import { RepoSelector } from '@/components/RepoSelector';
import { BuildProgress } from '@/components/BuildProgress';
import { BuildHistory } from '@/components/BuildHistory';
import { callEdgeFunction } from '@/lib/supabase';
import type { BuildRecord, GitHubRepo } from '@/types';

type AppView = 'connect' | 'select' | 'build';

export default function App() {
  const [view, setView] = useState<AppView>('connect');
  const [token, setToken] = useState('');
  const [connectLoading, setConnectLoading] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);
  const [activeBuild, setActiveBuild] = useState<BuildRecord | null>(null);
  const [historyRefresh, setHistoryRefresh] = useState(0);

  const handleConnect = async (t: string) => {
    setConnectLoading(true);
    setConnectError(null);
    try {
      // Validate token by fetching user info
      const data = await callEdgeFunction({ action: 'list-repos', github_token: t });
      if (data.repos) {
        setToken(t);
        setView('select');
      }
    } catch (err) {
      setConnectError(
        err instanceof Error
          ? err.message
          : 'Failed to connect. Check your token and try again.'
      );
    } finally {
      setConnectLoading(false);
    }
  };

  const handleDisconnect = () => {
    setToken('');
    setView('connect');
    setActiveBuild(null);
  };

  const handleStartBuild = async (repo: GitHubRepo, branch: string) => {
    try {
      const data = await callEdgeFunction({
        action: 'start-build',
        github_token: token,
        repo_owner: repo.owner,
        repo_name: repo.name,
        branch,
        repo_url: repo.html_url,
      });

      if (data.build) {
        setActiveBuild(data.build as BuildRecord);
        setView('build');
        setHistoryRefresh((n) => n + 1);
      }
    } catch (err) {
      setConnectError(
        err instanceof Error ? err.message : 'Failed to start build. Please try again.'
      );
    }
  };

  const handleBuildComplete = () => {
    setHistoryRefresh((n) => n + 1);
  };

  const handleSelectBuildFromHistory = (build: BuildRecord) => {
    setActiveBuild(build);
    setView('build');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-lg border-b border-slate-200/60">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center shadow-lg">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 leading-tight">
                APK Builder
              </h1>
              <p className="text-[10px] text-slate-500 leading-tight">
                GitHub → APK in one click
              </p>
            </div>
          </div>

          {token && view !== 'connect' && (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200">
                <Github className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-xs font-semibold text-emerald-700">Connected</span>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {view === 'connect' && (
          <div className="space-y-8">
            {/* Hero */}
            <div className="text-center max-w-2xl mx-auto mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/5 border border-slate-900/10 mb-4">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span className="text-xs font-semibold text-slate-700">
                  Automated APK Build System
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
                Turn your GitHub repos
                <br />
                into installable APKs
              </h2>
              <p className="text-slate-500 mt-4 text-sm sm:text-base max-w-lg mx-auto">
                Connect your GitHub account, pick a repository, select a branch —
                and let the builder handle the rest. Real-time logs, status tracking,
                and one-click download.
              </p>

              <div className="grid grid-cols-3 gap-4 mt-8 max-w-lg mx-auto">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                    <Github className="w-5 h-5 text-blue-600" />
                  </div>
                  <span className="text-xs font-medium text-slate-600 text-center">
                    1. Connect
                  </span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center">
                    <Smartphone className="w-5 h-5 text-amber-600" />
                  </div>
                  <span className="text-xs font-medium text-slate-600 text-center">
                    2. Select
                  </span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center">
                    <Zap className="w-5 h-5 text-emerald-600" />
                  </div>
                  <span className="text-xs font-medium text-slate-600 text-center">
                    3. Build
                  </span>
                </div>
              </div>
            </div>

            <GitHubConnect
              onConnect={handleConnect}
              loading={connectLoading}
              error={connectError}
            />

            <div className="flex items-center justify-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <Shield className="w-4 h-4" />
                <span>Token stored securely</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Github className="w-4 h-4" />
                <span>Requires repo + workflow scope</span>
              </div>
            </div>
          </div>
        )}

        {view === 'select' && (
          <div className="grid lg:grid-cols-[1fr_360px] gap-6 items-start">
            <div className="space-y-4">
              <RepoSelector
                token={token}
                onStartBuild={handleStartBuild}
                onDisconnect={handleDisconnect}
              />
            </div>
            <div className="lg:sticky lg:top-24">
              <BuildHistory
                onSelectBuild={handleSelectBuildFromHistory}
                refreshTrigger={historyRefresh}
              />
            </div>
          </div>
        )}

        {view === 'build' && activeBuild && (
          <div className="grid lg:grid-cols-[1fr_340px] gap-6 items-start">
            <BuildProgress
              build={activeBuild}
              onBack={() => setView('select')}
              onBuildComplete={handleBuildComplete}
            />
            <div className="lg:sticky lg:top-24">
              <BuildHistory
                onSelectBuild={handleSelectBuildFromHistory}
                refreshTrigger={historyRefresh}
              />
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/60 bg-white/50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <p className="text-xs text-slate-400">
            APK Builder — Automated Android builds from GitHub
          </p>
        </div>
      </footer>
    </div>
  );
}
