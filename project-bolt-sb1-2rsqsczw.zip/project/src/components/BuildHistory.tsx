import { useEffect, useState } from 'react';
import {
  History,
  CheckCircle2,
  XCircle,
  Loader2,
  Clock,
  GitBranch,
  ChevronRight,
  Trash2,
} from 'lucide-react';
import type { BuildRecord } from '@/types';
import { supabase } from '@/lib/supabase';

interface BuildHistoryProps {
  onSelectBuild: (build: BuildRecord) => void;
  refreshTrigger: number;
}

export function BuildHistory({ onSelectBuild, refreshTrigger }: BuildHistoryProps) {
  const [builds, setBuilds] = useState<BuildRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadBuilds = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('builds')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      if (!error && data) {
        setBuilds(data as BuildRecord[]);
      }
      setLoading(false);
    };

    loadBuilds();
  }, [refreshTrigger]);

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await supabase.from('builds').delete().eq('id', id);
    setBuilds(builds.filter((b) => b.id !== id));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
      </div>
    );
  }

  if (builds.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-2">
        <History className="w-8 h-8 text-slate-300" />
        <p className="text-sm text-slate-400">No builds yet</p>
        <p className="text-xs text-slate-400">Your build history will appear here</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-200/60 overflow-hidden">
      <div className="p-4 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-slate-500" />
          <h3 className="text-sm font-bold text-slate-900">Build History</h3>
          <span className="text-xs text-slate-400 ml-auto">{builds.length} builds</span>
        </div>
      </div>
      <div className="max-h-96 overflow-y-auto divide-y divide-slate-50">
        {builds.map((build) => {
          const isComplete = build.status === 'success' || build.status === 'failed';
          const isActive = !isComplete;

          return (
            <div
              key={build.id}
              onClick={() => onSelectBuild(build)}
              className="flex items-center gap-3 p-3 hover:bg-slate-50 cursor-pointer transition-all group"
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  build.status === 'success'
                    ? 'bg-emerald-50'
                    : build.status === 'failed'
                    ? 'bg-red-50'
                    : 'bg-slate-100'
                }`}
              >
                {build.status === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : build.status === 'failed' ? (
                  <XCircle className="w-4 h-4 text-red-600" />
                ) : (
                  <Loader2 className="w-4 h-4 text-slate-500 animate-spin" />
                )}
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-slate-900 truncate">
                  {build.repo_owner}/{build.repo_name}
                </p>
                <div className="flex items-center gap-2 mt-0.5">
                  <GitBranch className="w-3 h-3 text-slate-400" />
                  <span className="text-xs text-slate-500 font-mono">{build.branch}</span>
                  <span className="text-xs text-slate-300">·</span>
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span className="text-xs text-slate-500">
                    {new Date(build.created_at).toLocaleDateString()}{' '}
                    {new Date(build.created_at).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>

              <span
                className={`text-xs font-semibold px-2 py-0.5 rounded-md flex-shrink-0 ${
                  build.status === 'success'
                    ? 'text-emerald-700 bg-emerald-50'
                    : build.status === 'failed'
                    ? 'text-red-700 bg-red-50'
                    : 'text-slate-600 bg-slate-100'
                }`}
              >
                {isActive ? build.status : build.status}
              </span>

              <button
                onClick={(e) => handleDelete(build.id, e)}
                className="p-1 rounded text-slate-300 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all flex-shrink-0"
                title="Delete build record"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-600 transition-colors flex-shrink-0" />
            </div>
          );
        })}
      </div>
    </div>
  );
}
