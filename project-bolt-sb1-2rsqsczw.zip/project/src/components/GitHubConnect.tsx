import { useState } from 'react';
import { Github, KeyRound, Eye, EyeOff, Loader2, AlertCircle } from 'lucide-react';

interface GitHubConnectProps {
  onConnect: (token: string) => void;
  loading: boolean;
  error: string | null;
}

export function GitHubConnect({ onConnect, loading, error }: GitHubConnectProps) {
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (token.trim()) {
      onConnect(token.trim());
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200/60 p-8">
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
            <Github className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Connect GitHub</h2>
          <p className="text-sm text-slate-500 mt-2 max-w-xs">
            Enter a GitHub Personal Access Token to link your repositories and start building APKs.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-semibold text-slate-700 mb-2 block">
              Personal Access Token
            </label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type={showToken ? 'text' : 'password'}
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                className="w-full pl-11 pr-11 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10 outline-none transition-all text-slate-900 text-sm font-mono"
                disabled={loading}
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition-colors"
              >
                {showToken ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !token.trim()}
            className="w-full py-3 rounded-xl bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-lg shadow-slate-900/20"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Connecting...
              </>
            ) : (
              <>
                <Github className="w-5 h-5" />
                Connect & View Repositories
              </>
            )}
          </button>
        </form>

        <div className="mt-6 p-4 rounded-xl bg-blue-50 border border-blue-200">
          <p className="text-xs text-blue-800 leading-relaxed">
            Need a token? Go to GitHub → Settings → Developer settings → Personal access tokens →
            Generate new token with <code className="font-mono font-semibold">repo</code> and{' '}
            <code className="font-mono font-semibold">workflow</code> scopes.
          </p>
        </div>
      </div>
    </div>
  );
}
