import { useEffect, useRef, useState } from 'react';
import {
  Loader2,
  CheckCircle2,
  XCircle,
  Download,
  Terminal,
  ArrowLeft,
  Copy,
  Check,
  ExternalLink,
} from 'lucide-react';
import type { BuildRecord, BuildStatus } from '@/types';
import { callEdgeFunction } from '@/lib/supabase';

interface BuildProgressProps {
  build: BuildRecord;
  onBack: () => void;
  onBuildComplete: (build: BuildRecord) => void;
}

const STATUS_CONFIG: Record<
  BuildStatus,
  { label: string; color: string; bgColor: string; icon: typeof Loader2 }
> = {
  queued: {
    label: 'Queued',
    color: 'text-slate-600',
    bgColor: 'bg-slate-100',
    icon: Loader2,
  },
  cloning: {
    label: 'Cloning Repository',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    icon: Loader2,
  },
  configuring: {
    label: 'Configuring Environment',
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    icon: Loader2,
  },
  building: {
    label: 'Building APK',
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    icon: Loader2,
  },
  success: {
    label: 'Build Successful',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    icon: CheckCircle2,
  },
  failed: {
    label: 'Build Failed',
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    icon: XCircle,
  },
};

const BUILD_STEPS: BuildStatus[] = ['cloning', 'configuring', 'building', 'success'];

export function BuildProgress({ build, onBack, onBuildComplete }: BuildProgressProps) {
  const [currentBuild, setCurrentBuild] = useState<BuildRecord>(build);
  const [copied, setCopied] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isComplete = currentBuild.status === 'success' || currentBuild.status === 'failed';

  useEffect(() => {
    if (isComplete) {
      onBuildComplete(currentBuild);
      return;
    }

    const poll = async () => {
      try {
        const data = await callEdgeFunction({ action: 'check-build', build_id: currentBuild.id });
        if (data.build) {
          setCurrentBuild(data.build);
        }
      } catch {
        // silent retry
      }
      pollRef.current = setTimeout(poll, 5000);
    };

    pollRef.current = setTimeout(poll, 3000);

    return () => {
      if (pollRef.current) clearTimeout(pollRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentBuild.status, currentBuild.id]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentBuild.logs]);

  const statusConfig = STATUS_CONFIG[currentBuild.status];
  const StatusIcon = statusConfig.icon;
  const isActive = !isComplete;

  const currentStepIndex = BUILD_STEPS.indexOf(currentBuild.status);
  const progressPercent = isComplete
    ? currentBuild.status === 'success'
      ? 100
      : Math.max(25, currentStepIndex * 25)
    : Math.max(10, currentStepIndex * 25 + 15);

  const handleCopyLogs = () => {
    navigator.clipboard.writeText(currentBuild.logs || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const logLines = (currentBuild.logs || '').split('\n');

  return (
    <div className="w-full max-w-3xl mx-auto">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 font-medium mb-4 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to repositories
      </button>

      <div className="bg-white rounded-2xl shadow-xl border border-slate-200/60 overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <h2 className="text-xl font-bold text-slate-900 truncate">
                {currentBuild.repo_owner}/{currentBuild.repo_name}
              </h2>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-xs text-slate-500 font-mono bg-slate-100 px-2 py-0.5 rounded">
                  {currentBuild.branch}
                </span>
                <span className="text-xs text-slate-400">
                  {new Date(currentBuild.created_at).toLocaleString()}
                </span>
              </div>
            </div>
            <div
              className={`flex items-center gap-2 px-4 py-2 rounded-xl ${statusConfig.bgColor} flex-shrink-0`}
            >
              <StatusIcon
                className={`w-5 h-5 ${statusConfig.color} ${isActive ? 'animate-spin' : ''}`}
              />
              <span className={`text-sm font-semibold ${statusConfig.color}`}>
                {statusConfig.label}
              </span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-600">Progress</span>
              <span className="text-xs font-bold text-slate-900">{progressPercent}%</span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ease-out ${
                  currentBuild.status === 'failed'
                    ? 'bg-red-500'
                    : currentBuild.status === 'success'
                    ? 'bg-emerald-500'
                    : 'bg-gradient-to-r from-blue-500 to-indigo-500'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Steps */}
          <div className="flex items-center gap-1 mt-4">
            {BUILD_STEPS.map((step, idx) => {
              const stepConfig = STATUS_CONFIG[step];
              const StepIcon = stepConfig.icon;
              const isDone = isComplete
                ? currentBuild.status === 'success' || idx < currentStepIndex
                : idx < currentStepIndex;
              const isCurrent = currentBuild.status === step && !isComplete;

              return (
                <div key={step} className="flex items-center flex-1 last:flex-none">
                  <div className="flex flex-col items-center gap-1">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                        isDone
                          ? 'bg-emerald-500 text-white'
                          : isCurrent
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : isCurrent ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <StepIcon className="w-4 h-4" />
                      )}
                    </div>
                    <span
                      className={`text-[10px] font-medium whitespace-nowrap ${
                        isDone || isCurrent ? 'text-slate-700' : 'text-slate-400'
                      }`}
                    >
                      {stepConfig.label}
                    </span>
                  </div>
                  {idx < BUILD_STEPS.length - 1 && (
                    <div
                      className={`h-0.5 flex-1 mx-1 transition-all ${
                        isDone ? 'bg-emerald-500' : 'bg-slate-200'
                      }`}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Terminal logs */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-semibold text-slate-700">Build Logs</span>
            </div>
            <button
              onClick={handleCopyLogs}
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 font-medium transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy
                </>
              )}
            </button>
          </div>
          <div className="bg-slate-900 rounded-xl p-4 max-h-80 overflow-y-auto font-mono text-xs leading-relaxed">
            {logLines.map((line, idx) => (
              <div
                key={idx}
                className={`whitespace-pre-wrap break-all ${
                  line.startsWith('[ERROR]')
                    ? 'text-red-400'
                    : line.startsWith('[WARN]')
                    ? 'text-amber-400'
                    : line.startsWith('[OK]')
                    ? 'text-emerald-400'
                    : line.startsWith('[SUCCESS]')
                    ? 'text-emerald-300 font-bold'
                    : line.startsWith('[INFO]')
                    ? 'text-slate-400'
                    : line.startsWith('[STEP')
                    ? 'text-blue-400 font-semibold'
                    : line.startsWith('>') || line.startsWith('$')
                    ? 'text-green-400'
                    : line.startsWith('BUILD')
                    ? 'text-cyan-400 font-semibold'
                    : 'text-slate-300'
                }`}
              >
                {line || '\u00a0'}
              </div>
            ))}
            {isActive && (
              <div className="flex items-center gap-1 mt-1 text-slate-500">
                <span className="w-2 h-4 bg-slate-500 animate-pulse" />
              </div>
            )}
            <div ref={logEndRef} />
          </div>
        </div>

        {/* Footer — download */}
        {currentBuild.status === 'success' && (currentBuild.apk_url || currentBuild.apk_download_url) && (
          <div className="p-6 border-t border-slate-100 bg-emerald-50/50">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">APK built successfully!</p>
                  <p className="text-xs text-slate-500">
                    Your APK is ready for download from GitHub Releases
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {currentBuild.workflow_html_url && (
                  <a
                    href={currentBuild.workflow_html_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-medium text-sm hover:bg-slate-200 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Actions
                  </a>
                )}
                <a
                  href={currentBuild.apk_download_url || currentBuild.apk_url || '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
                >
                  <Download className="w-5 h-5" />
                  Download APK
                </a>
              </div>
            </div>
          </div>
        )}

        {currentBuild.status === 'failed' && (
          <div className="p-6 border-t border-slate-100 bg-red-50/50">
            <div className="flex items-start gap-3">
              <XCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-bold text-slate-900">Build failed</p>
                <p className="text-xs text-slate-600 mt-1">
                  {currentBuild.error_message || 'Check the logs above for details.'}
                </p>
                {currentBuild.workflow_html_url && (
                  <a
                    href={currentBuild.workflow_html_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 mt-2 text-xs text-blue-600 hover:text-blue-700 font-medium"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    View GitHub Actions logs
                  </a>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
