import { useState, useMemo } from 'react';
import {
  Search,
  GitBranch,
  Lock,
  Globe,
  Loader2,
  ChevronRight,
  Star,
  AlertCircle,
  RefreshCw,
  LogOut,
} from 'lucide-react';
import type { GitHubRepo, GitHubBranch } from '@/types';
import { callEdgeFunction } from '@/lib/supabase';

interface RepoSelectorProps {
  token: string;
  onStartBuild: (repo: GitHubRepo, branch: string) => void;
  onDisconnect: () => void;
}

export function RepoSelector({ token, onStartBuild, onDisconnect }: RepoSelectorProps) {
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [selectedRepo, setSelectedRepo] = useState<GitHubRepo | null>(null);
  const [branches, setBranches] = useState<GitHubBranch[]>([]);
  const [selectedBranch, setSelectedBranch] = useState('');
  const [branchesLoading, setBranchesLoading] = useState(false);
  const [branchesError, setBranchesError] = useState<string | null>(null);
  const [building, setBuilding] = useState(false);
  const [languageFilter, setLanguageFilter] = useState<string>('all');

  const loadRepos = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await callEdgeFunction({ action: 'list-repos', github_token: token });
      setRepos(data.repos);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load repositories');
    } finally {
      setLoading(false);
    }
  };

  useState(() => {
    loadRepos();
  });

  const loadBranches = async (repo: GitHubRepo) => {
    setSelectedRepo(repo);
    setSelectedBranch(repo.default_branch);
    setBranchesLoading(true);
    setBranchesError(null);
    setBranches([]);
    try {
      const data = await callEdgeFunction({
        action: 'list-branches',
        github_token: token,
        repo_owner: repo.owner,
        repo_name: repo.name,
      });
      setBranches(data.branches);
    } catch (err) {
      setBranchesError(err instanceof Error ? err.message : 'Failed to load branches');
    } finally {
      setBranchesLoading(false);
    }
  };

  const handleBuild = async () => {
    if (!selectedRepo || !selectedBranch) return;
    setBuilding(true);
    try {
      onStartBuild(selectedRepo, selectedBranch);
    } finally {
      setBuilding(false);
    }
  };

  const languages = useMemo(() => {
    const langs = new Set<string>();
    repos.forEach((r) => {
      if (r.language) langs.add(r.language);
    });
    return Array.from(langs).sort();
  }, [repos]);

  const filteredRepos = useMemo(() => {
    return repos.filter((r) => {
      const matchesSearch =
        r.full_name.toLowerCase().includes(search.toLowerCase()) ||
        (r.description || '').toLowerCase().includes(search.toLowerCase());
      const matchesLang = languageFilter === 'all' || r.language === languageFilter;
      return matchesSearch && matchesLang;
    });
  }, [repos, search, languageFilter]);

  if (selectedRepo) {
    return (
      <div className="w-full max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200/60 overflow-hidden">
          <div className="p-6 border-b border-slate-100">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center flex-shrink-0">
                  {selectedRepo.private ? (
                    <Lock className="w-5 h-5 text-white" />
                  ) : (
                    <Globe className="w-5 h-5 text-white" />
                  )}
                </div>
                <div className="min-w-0">
                  <h3 className="text-lg font-bold text-slate-900 truncate">
                    {selectedRepo.full_name}
                  </h3>
                  {selectedRepo.description && (
                    <p className="text-sm text-slate-500 mt-1 line-clamp-2">
                      {selectedRepo.description}
                    </p>
                  )}
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedRepo(null);
                  setBranches([]);
                }}
                className="text-sm text-slate-500 hover:text-slate-900 font-medium flex-shrink-0"
              >
                Back
              </button>
            </div>
          </div>

          <div className="p-6">
            <label className="text-sm font-semibold text-slate-700 mb-3 block">
              Select Branch
            </label>
            {branchesLoading ? (
              <div className="flex items-center gap-2 text-slate-500 py-4">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="text-sm">Loading branches...</span>
              </div>
            ) : branchesError ? (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-700">{branchesError}</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {branches.map((branch) => (
                  <button
                    key={branch.name}
                    onClick={() => setSelectedBranch(branch.name)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${
                      selectedBranch === branch.name
                        ? 'border-slate-900 bg-slate-50 ring-2 ring-slate-900/10'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <GitBranch
                      className={`w-4 h-4 flex-shrink-0 ${
                        selectedBranch === branch.name ? 'text-slate-900' : 'text-slate-400'
                      }`}
                    />
                    <span
                      className={`text-sm font-medium ${
                        selectedBranch === branch.name ? 'text-slate-900' : 'text-slate-600'
                      }`}
                    >
                      {branch.name}
                    </span>
                    {selectedBranch === branch.name && (
                      <ChevronRight className="w-4 h-4 text-slate-900 ml-auto" />
                    )}
                  </button>
                ))}
              </div>
            )}

            <button
              onClick={handleBuild}
              disabled={!selectedBranch || building}
              className="w-full mt-6 py-3.5 rounded-xl bg-emerald-600 text-white font-semibold text-sm hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
            >
              {building ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Starting Build...
                </>
              ) : (
                <>
                  <GitBranch className="w-5 h-5" />
                  Build APK from {selectedBranch || 'branch'}
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200/60 overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">Select Repository</h2>
              <p className="text-sm text-slate-500 mt-1">
                Choose a repository to build an APK from
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={loadRepos}
                className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-all"
                title="Refresh repositories"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
              <button
                onClick={onDisconnect}
                className="p-2 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-all"
                title="Disconnect GitHub"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search repositories..."
              className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10 outline-none transition-all text-sm text-slate-900"
            />
          </div>

          {languages.length > 0 && (
            <div className="flex items-center gap-2 mt-3 flex-wrap">
              <button
                onClick={() => setLanguageFilter('all')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                  languageFilter === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              {languages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => setLanguageFilter(lang)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                    languageFilter === lang
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="max-h-[480px] overflow-y-auto">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16 gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
              <p className="text-sm text-slate-500">Loading your repositories...</p>
            </div>
          ) : error ? (
            <div className="p-6">
              <div className="flex items-start gap-2 p-4 rounded-xl bg-red-50 border border-red-200">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-red-700 font-medium">{error}</p>
                  <button
                    onClick={loadRepos}
                    className="text-sm text-red-600 hover:text-red-700 font-medium mt-2"
                  >
                    Try again
                  </button>
                </div>
              </div>
            </div>
          ) : filteredRepos.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 gap-2">
              <p className="text-sm text-slate-500">No repositories found</p>
              <p className="text-xs text-slate-400">
                {search ? 'Try a different search term' : 'Create a repository on GitHub first'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredRepos.map((repo) => (
                <button
                  key={repo.id}
                  onClick={() => loadBranches(repo)}
                  className="w-full flex items-center gap-4 p-4 hover:bg-slate-50 transition-all text-left group"
                >
                  <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                    {repo.private ? (
                      <Lock className="w-5 h-5 text-slate-500" />
                    ) : (
                      <Globe className="w-5 h-5 text-slate-500" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-sm font-semibold text-slate-900 truncate">
                      {repo.full_name}
                    </h4>
                    {repo.description && (
                      <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                        {repo.description}
                      </p>
                    )}
                    <div className="flex items-center gap-3 mt-1.5">
                      {repo.language && (
                        <span className="text-xs text-slate-400 font-medium">
                          {repo.language}
                        </span>
                      )}
                      <span className="text-xs text-slate-400">
                        Updated {new Date(repo.updated_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-slate-600 transition-colors flex-shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {!loading && !error && repos.length > 0 && (
          <div className="p-3 border-t border-slate-100 text-center">
            <span className="text-xs text-slate-400">
              {filteredRepos.length} of {repos.length} repositories
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
