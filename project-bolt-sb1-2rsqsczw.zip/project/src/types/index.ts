export type BuildStatus = 'queued' | 'cloning' | 'configuring' | 'building' | 'success' | 'failed';

export interface BuildRecord {
  id: string;
  github_token: string;
  repo_url: string;
  repo_owner: string;
  repo_name: string;
  branch: string;
  status: BuildStatus;
  logs: string;
  apk_url: string | null;
  apk_download_url: string | null;
  release_html_url: string | null;
  workflow_html_url: string | null;
  workflow_run_id: number | null;
  error_message: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export interface GitHubRepo {
  id: number;
  name: string;
  full_name: string;
  html_url: string;
  owner: string;
  description: string | null;
  language: string | null;
  default_branch: string;
  updated_at: string;
  private: boolean;
}

export interface GitHubBranch {
  name: string;
  sha: string;
}
