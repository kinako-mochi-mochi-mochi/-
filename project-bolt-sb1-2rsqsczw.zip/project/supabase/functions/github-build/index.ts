import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BuildRequestBody {
  action: "list-repos" | "list-branches" | "start-build" | "check-build" | "get-build";
  github_token?: string;
  repo_owner?: string;
  repo_name?: string;
  branch?: string;
  repo_url?: string;
  build_id?: string;
}

const GH_HEADERS = (token: string) => ({
  Authorization: `Bearer ${token}`,
  Accept: "application/vnd.github.v3+json",
  "X-GitHub-Api-Version": "2022-11-28",
});

// The GitHub Actions workflow file content that will be pushed to the repo.
// This workflow checks out the branch, sets up Java + Android SDK, runs Gradle,
// and uploads the APK as a release asset.
const WORKFLOW_YML = `name: APK Build
on:
  workflow_dispatch:
    inputs:
      branch:
        description: 'Branch to build'
        required: true
        default: 'main'

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4
        with:
          ref: \${{ inputs.branch }}

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Grant execute permission for gradlew
        run: chmod +x ./gradlew
        continue-on-error: true

      - name: Build debug APK
        run: ./gradlew assembleDebug --no-daemon

      - name: Find APK
        id: find-apk
        run: |
          APK_PATH=$(find . -path "*/build/outputs/apk/debug/*.apk" -type f | head -1)
          if [ -z "$APK_PATH" ]; then
            echo "::error::No APK found in build/outputs/apk/debug/"
            exit 1
          fi
          echo "apk_path=$APK_PATH" >> $GITHUB_OUTPUT
          APK_NAME=$(basename "$APK_PATH")
          echo "apk_name=$APK_NAME" >> $GITHUB_OUTPUT
          APK_SIZE=$(stat -c%s "$APK_PATH" 2>/dev/null || stat -f%z "$APK_PATH")
          echo "apk_size=$APK_SIZE" >> $GITHUB_OUTPUT

      - name: Create release and upload APK
        env:
          GH_TOKEN: \${{ secrets.GITHUB_TOKEN }}
        run: |
          TAG="apk-\${{ github.run_number }}-\$(date +%s)"
          gh release create "$TAG" \${{ steps.find-apk.outputs.apk_path }} \\
            --title "APK Build #\${{ github.run_number }}" \\
            --notes "Debug APK built from branch \${{ inputs.branch }}" \\
            --target \${{ inputs.branch }}
          echo "tag=$TAG" >> $GITHUB_ENV
`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: BuildRequestBody = await req.json();
    const { action } = body;

    if (action === "list-repos") {
      return await handleListRepos(body.github_token!);
    }

    if (action === "list-branches") {
      return await handleListBranches(
        body.github_token!,
        body.repo_owner!,
        body.repo_name!
      );
    }

    if (action === "start-build") {
      return await handleStartBuild(supabase, body);
    }

    if (action === "check-build") {
      return await handleCheckBuild(supabase, body);
    }

    if (action === "get-build") {
      return await handleGetBuild(supabase, body.build_id!);
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ─── GitHub Actions workflow file path ───
const WORKFLOW_PATH = ".github/workflows/apk-build.yml";
const WORKFLOW_REF = "heads/.github/workflows/apk-build.yml";

// ─── Helper: GitHub API fetch with error handling ───
async function ghFetch(
  url: string,
  token: string,
  options?: RequestInit
): Promise<{ ok: boolean; status: number; data: unknown; raw: string }> {
  const resp = await fetch(url, {
    ...options,
    headers: {
      ...GH_HEADERS(token),
      ...(options?.headers || {}),
    },
  });
  const raw = await resp.text();
  let data: unknown = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = raw;
  }
  return { ok: resp.ok, status: resp.status, data, raw };
}

// ─── List repos ───
async function handleListRepos(token: string): Promise<Response> {
  const repos: Array<{
    id: number;
    name: string;
    full_name: string;
    html_url: string;
    owner: { login: string };
    description: string | null;
    language: string | null;
    default_branch: string;
    updated_at: string;
    private: boolean;
  }> = [];

  let page = 1;
  let hasMore = true;

  while (hasMore && page <= 10) {
    const { ok, status, data } = await ghFetch(
      `https://api.github.com/user/repos?per_page=100&page=${page}&sort=updated&type=all`,
      token
    );

    if (!ok) {
      return jsonResponse(
        { error: `GitHub API error: ${status} — ${(data as { message?: string })?.message || ""}` },
        status
      );
    }

    const pageRepos = data as typeof repos;
    if (!Array.isArray(pageRepos) || pageRepos.length === 0) {
      hasMore = false;
    } else {
      repos.push(...pageRepos);
      page++;
    }
  }

  const formatted = repos.map((r) => ({
    id: r.id,
    name: r.name,
    full_name: r.full_name,
    html_url: r.html_url,
    owner: r.owner.login,
    description: r.description,
    language: r.language,
    default_branch: r.default_branch,
    updated_at: r.updated_at,
    private: r.private,
  }));

  return jsonResponse({ repos: formatted });
}

// ─── List branches ───
async function handleListBranches(
  token: string,
  owner: string,
  repo: string
): Promise<Response> {
  const { ok, status, data } = await ghFetch(
    `https://api.github.com/repos/${owner}/${repo}/branches?per_page=100`,
    token
  );

  if (!ok) {
    return jsonResponse(
      { error: `GitHub API error: ${status} — ${(data as { message?: string })?.message || ""}` },
      status
    );
  }

  const branches = data as Array<{ name: string; commit: { sha: string } }>;
  return jsonResponse({
    branches: branches.map((b) => ({ name: b.name, sha: b.commit.sha })),
  });
}

// ─── Start build: push workflow file, trigger GitHub Actions ───
async function handleStartBuild(
  supabase: ReturnType<typeof createClient>,
  body: BuildRequestBody
): Promise<Response> {
  const {
    github_token: token,
    repo_owner: owner,
    repo_name: repo,
    branch = "main",
    repo_url,
  } = body;

  if (!token || !owner || !repo || !repo_url) {
    return jsonResponse({ error: "Missing required fields" }, 400);
  }

  let logs = `[INFO] Build started for ${owner}/${repo} on branch ${branch}\n`;

  // Step 1: Validate repo access
  logs += `[STEP 1/5] Verifying repository access...\n`;
  const repoResult = await ghFetch(
    `https://api.github.com/repos/${owner}/${repo}`,
    token
  );

  if (!repoResult.ok) {
    return jsonResponse(
      { error: `Repository not accessible: ${repoResult.status}` },
      400
    );
  }

  const repoData = repoResult.data as {
    full_name: string;
    default_branch: string;
    language: string | null;
    private: boolean;
  };

  logs += `[INFO] Repository: ${repoData.full_name}\n`;
  logs += `[INFO] Default branch: ${repoData.default_branch}\n`;
  logs += `[INFO] Language: ${repoData.language || "unknown"}\n`;
  logs += `[INFO] Private: ${repoData.private ? "yes" : "no"}\n`;
  logs += `[OK] Repository access verified.\n\n`;

  // Create build record early so we have an ID
  const { data: build, error: insertError } = await supabase
    .from("builds")
    .insert({
      github_token: token,
      repo_url,
      repo_owner: owner,
      repo_name: repo,
      branch,
      status: "cloning",
      logs,
    })
    .select()
    .single();

  if (insertError || !build) {
    return jsonResponse({ error: "Failed to create build record" }, 500);
  }

  const buildId = build.id;

  try {
    // Step 2: Push the workflow file to the repo
    logs += `[STEP 2/5] Deploying build workflow to repository...\n`;

    // Check if the workflow file already exists
    const existingWorkflow = await ghFetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${WORKFLOW_PATH}?ref=${branch}`,
      token
    );

    let workflowPayload: Record<string, unknown> = {
      message: "Add APK build workflow [APK Builder]",
      content: btoa(unescape(encodeURIComponent(WORKFLOW_YML))),
      branch,
    };

    if (existingWorkflow.ok) {
      const existingData = existingWorkflow.data as { sha: string };
      workflowPayload.sha = existingData.sha;
      logs += `[INFO] Updating existing workflow file.\n`;
    } else {
      logs += `[INFO] Creating new workflow file.\n`;
    }

    const pushResult = await ghFetch(
      `https://api.github.com/repos/${owner}/${repo}/contents/${WORKFLOW_PATH}`,
      token,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(workflowPayload),
      }
    );

    if (!pushResult.ok) {
      const errMsg = (pushResult.data as { message?: string })?.message || "Unknown error";
      logs += `[ERROR] Failed to push workflow: ${errMsg}\n`;
      await supabase
        .from("builds")
        .update({
          status: "failed",
          logs,
          error_message: `Failed to push workflow: ${errMsg}`,
          updated_at: new Date().toISOString(),
          completed_at: new Date().toISOString(),
        })
        .eq("id", buildId);
      return jsonResponse({ error: `Failed to push workflow: ${errMsg}` }, 500);
    }

    logs += `[OK] Workflow file pushed to ${WORKFLOW_PATH}\n\n`;

    // Wait briefly for GitHub to register the workflow
    await sleep(2000);

    // Step 3: Trigger the workflow via workflow_dispatch
    logs += `[STEP 3/5] Triggering GitHub Actions build...\n`;

    const triggerResult = await ghFetch(
      `https://api.github.com/repos/${owner}/${repo}/actions/workflows/apk-build.yml/dispatches`,
      token,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ref: branch,
          inputs: { branch },
        }),
      }
    );

    if (!triggerResult.ok) {
      const errMsg = (triggerResult.data as { message?: string })?.message || "Unknown error";
      logs += `[ERROR] Failed to trigger workflow: ${errMsg}\n`;
      await supabase
        .from("builds")
        .update({
          status: "failed",
          logs,
          error_message: `Failed to trigger workflow: ${errMsg}`,
          updated_at: new Date().toISOString(),
          completed_at: new Date().toISOString(),
        })
        .eq("id", buildId);
      return jsonResponse({ error: `Failed to trigger workflow: ${errMsg}` }, 500);
    }

    logs += `[OK] Workflow dispatched on branch "${branch}"\n`;
    logs += `[INFO] Waiting for GitHub Actions to start...\n\n`;

    // Update build status to building
    await supabase
      .from("builds")
      .update({
        status: "building",
        logs,
        updated_at: new Date().toISOString(),
      })
      .eq("id", buildId);

    // Step 4: Poll for the workflow run ID (it takes a few seconds to appear)
    let workflowRunId: number | null = null;
    let workflowHtmlUrl: string | null = null;

    for (let attempt = 0; attempt < 15; attempt++) {
      await sleep(3000);

      const runsResult = await ghFetch(
        `https://api.github.com/repos/${owner}/${repo}/actions/runs?per_page=5&event=workflow_dispatch`,
        token
      );

      if (runsResult.ok) {
        const runsData = runsResult.data as {
          workflow_runs: Array<{
            id: number;
            html_url: string;
            status: string;
            conclusion: string | null;
            created_at: string;
            head_branch: string;
            name: string;
          }>;
        };

        // Find the most recent run for our workflow
        const recentRun = runsData.workflow_runs.find(
          (r) => r.head_branch === branch && r.name === "APK Build"
        );

        if (recentRun) {
          workflowRunId = recentRun.id;
          workflowHtmlUrl = recentRun.html_url;
          logs += `[OK] GitHub Actions run started: #${recentRun.id}\n`;
          logs += `[INFO] Status: ${recentRun.status}\n`;
          logs += `[INFO] View on GitHub: ${recentRun.html_url}\n\n`;
          break;
        }
      }
    }

    if (!workflowRunId) {
      logs += `[WARN] Could not locate the workflow run. It may still be queued.\n`;
      logs += `[INFO] Check GitHub Actions tab manually.\n\n`;
    }

    // Step 5: Save workflow info and update build record
    logs += `[STEP 4/5] Build is running on GitHub Actions...\n`;
    logs += `[INFO] GitHub Actions is compiling your APK with Android SDK.\n`;
    logs += `[INFO] This typically takes 3-10 minutes.\n\n`;
    logs += `[STEP 5/5] Waiting for build completion...\n`;
    logs += `[INFO] Polling GitHub Actions for status updates...\n`;

    await supabase
      .from("builds")
      .update({
        status: "building",
        logs,
        workflow_run_id: workflowRunId,
        workflow_html_url: workflowHtmlUrl,
        updated_at: new Date().toISOString(),
      })
      .eq("id", buildId);

    const { data: finalBuild } = await supabase
      .from("builds")
      .select("*")
      .eq("id", buildId)
      .single();

    return jsonResponse({ build: finalBuild });
  } catch (err) {
    logs += `[ERROR] ${err.message}\n`;
    await supabase
      .from("builds")
      .update({
        status: "failed",
        logs,
        error_message: err.message,
        updated_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
      })
      .eq("id", buildId);

    return jsonResponse({ error: err.message }, 500);
  }
}

// ─── Check build: poll GitHub Actions for status + fetch release ───
async function handleCheckBuild(
  supabase: ReturnType<typeof createClient>,
  body: BuildRequestBody
): Promise<Response> {
  const { build_id: buildId } = body;
  if (!buildId) {
    return jsonResponse({ error: "Missing build_id" }, 400);
  }

  const { data: build, error } = await supabase
    .from("builds")
    .select("*")
    .eq("id", buildId)
    .single();

  if (error || !build) {
    return jsonResponse({ error: "Build not found" }, 404);
  }

  // If already complete, just return current state
  if (build.status === "success" || build.status === "failed") {
    return jsonResponse({ build });
  }

  const token = build.github_token;
  const owner = build.repo_owner;
  const repo = build.repo_name;
  const workflowRunId = build.workflow_run_id;
  let logs = build.logs || "";

  if (!workflowRunId) {
    // No workflow run ID yet — try to find it
    return jsonResponse({ build });
  }

  // Fetch workflow run status
  const runResult = await ghFetch(
    `https://api.github.com/repos/${owner}/${repo}/actions/runs/${workflowRunId}`,
    token
  );

  if (!runResult.ok) {
    return jsonResponse({ build });
  }

  const runData = runResult.data as {
    status: string;
    conclusion: string | null;
    html_url: string;
  };

  logs += `[INFO] GitHub Actions status: ${runData.status}`;
  if (runData.conclusion) {
    logs += ` → ${runData.conclusion}`;
  }
  logs += `\n`;

  // If still running, update logs and return
  if (runData.status === "queued" || runData.status === "in_progress") {
    await supabase
      .from("builds")
      .update({ logs, updated_at: new Date().toISOString() })
      .eq("id", buildId);

    const { data: updated } = await supabase
      .from("builds")
      .select("*")
      .eq("id", buildId)
      .single();

    return jsonResponse({ build: updated });
  }

  // Workflow finished — check conclusion
  if (runData.conclusion === "success") {
    logs += `[OK] GitHub Actions build completed successfully!\n`;
    logs += `[INFO] Looking for APK release...\n`;

    // Fetch the latest release
    const releaseResult = await ghFetch(
      `https://api.github.com/repos/${owner}/${repo}/releases/latest`,
      token
    );

    let apkDownloadUrl: string | null = null;
    let releaseHtmlUrl: string | null = null;

    if (releaseResult.ok) {
      const releaseData = releaseResult.data as {
        html_url: string;
        tag_name: string;
        assets: Array<{
          name: string;
          browser_download_url: string;
          size: number;
        }>;
      };

      releaseHtmlUrl = releaseData.html_url;

      // Find the APK asset
      const apkAsset = releaseData.assets.find(
        (a) => a.name.endsWith(".apk")
      );

      if (apkAsset) {
        apkDownloadUrl = apkAsset.browser_download_url;
        logs += `[OK] APK found: ${apkAsset.name}\n`;
        logs += `[INFO] Size: ${(apkAsset.size / 1024 / 1024).toFixed(1)} MB\n`;
        logs += `[INFO] Download URL: ${apkAsset.browser_download_url}\n`;
      } else {
        logs += `[WARN] No APK asset found in latest release.\n`;
        logs += `[INFO] Release URL: ${releaseData.html_url}\n`;
        // Use the release page as fallback
        apkDownloadUrl = releaseData.html_url;
      }
    } else {
      logs += `[WARN] Could not fetch release info. The release may still be processing.\n`;
      // Fallback to releases page
      apkDownloadUrl = `https://github.com/${owner}/${repo}/releases`;
    }

    logs += `\n[SUCCESS] Build completed successfully!\n`;
    logs += `[INFO] APK ready for download.\n`;

    await supabase
      .from("builds")
      .update({
        status: "success",
        logs,
        apk_url: apkDownloadUrl,
        apk_download_url: apkDownloadUrl,
        release_html_url: releaseHtmlUrl,
        updated_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
      })
      .eq("id", buildId);
  } else {
    // Build failed
    logs += `[ERROR] GitHub Actions build failed: ${runData.conclusion}\n`;
    logs += `[INFO] Check the workflow logs on GitHub for details.\n`;
    logs += `[INFO] Workflow URL: ${runData.html_url}\n`;

    await supabase
      .from("builds")
      .update({
        status: "failed",
        logs,
        error_message: `GitHub Actions build ${runData.conclusion}`,
        updated_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
      })
      .eq("id", buildId);
  }

  const { data: finalBuild } = await supabase
    .from("builds")
    .select("*")
    .eq("id", buildId)
    .single();

  return jsonResponse({ build: finalBuild });
}

// ─── Get build ───
async function handleGetBuild(
  supabase: ReturnType<typeof createClient>,
  buildId: string
): Promise<Response> {
  const { data: build, error } = await supabase
    .from("builds")
    .select("*")
    .eq("id", buildId)
    .single();

  if (error || !build) {
    return jsonResponse({ error: "Build not found" }, 404);
  }

  return jsonResponse({ build });
}

// ─── Utilities ───
function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
