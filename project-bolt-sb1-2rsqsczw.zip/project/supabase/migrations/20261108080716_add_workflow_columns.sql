/*
# Add workflow tracking columns to builds table

1. Modified Tables
- `builds`
  - Add `workflow_run_id` (bigint) — GitHub Actions workflow run ID for status tracking
  - Add `workflow_html_url` (text) — URL to view the workflow run on GitHub
  - Add `release_html_url` (text) — URL to the GitHub release containing the built APK
  - Add `apk_download_url` (text) — direct download URL for the built APK asset

2. Security
- No RLS changes needed — existing policies already allow full CRUD for anon + authenticated.
*/

ALTER TABLE builds ADD COLUMN IF NOT EXISTS workflow_run_id bigint;
ALTER TABLE builds ADD COLUMN IF NOT EXISTS workflow_html_url text;
ALTER TABLE builds ADD COLUMN IF NOT EXISTS release_html_url text;
ALTER TABLE builds ADD COLUMN IF NOT EXISTS apk_download_url text;
