/*
# Create builds table for APK Build Manager

1. New Tables
- `builds`
  - `id` (uuid, primary key) — unique build identifier
  - `github_token` (text, not null) — GitHub personal access token (stored encrypted in practice; here used for build process)
  - `repo_url` (text, not null) — full GitHub repository URL (e.g. https://github.com/owner/repo)
  - `repo_owner` (text, not null) — repository owner
  - `repo_name` (text, not null) — repository name
  - `branch` (text, not null, default 'main') — branch to build from
  - `status` (text, not null, default 'queued') — build status: queued, cloning, configuring, building, success, failed
  - `logs` (text, default '') — build log output
  - `apk_url` (text) — download URL for the built APK (if successful)
  - `error_message` (text) — error details if build failed
  - `created_at` (timestamptz, default now()) — when build was created
  - `updated_at` (timestamptz, default now()) — last status update
  - `completed_at` (timestamptz) — when build finished

2. Security
- Enable RLS on `builds`.
- Grant CRUD to `anon` + `authenticated` (single-tenant app, no sign-in required).
- Allow anon + authenticated full CRUD because the app is intentionally public/shared.
*/

CREATE TABLE IF NOT EXISTS builds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  github_token text NOT NULL,
  repo_url text NOT NULL,
  repo_owner text NOT NULL,
  repo_name text NOT NULL,
  branch text NOT NULL DEFAULT 'main',
  status text NOT NULL DEFAULT 'queued',
  logs text DEFAULT '',
  apk_url text,
  error_message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE builds ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON builds TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_builds" ON builds;
CREATE POLICY "anon_select_builds" ON builds FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_builds" ON builds;
CREATE POLICY "anon_insert_builds" ON builds FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_builds" ON builds;
CREATE POLICY "anon_update_builds" ON builds FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_builds" ON builds;
CREATE POLICY "anon_delete_builds" ON builds FOR DELETE
  TO anon, authenticated USING (true);

-- Index for sorting by most recent
CREATE INDEX IF NOT EXISTS idx_builds_created_at ON builds (created_at DESC);
